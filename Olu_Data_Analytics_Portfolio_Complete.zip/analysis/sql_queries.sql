-- SERVICE UTILIZATION | PORTFOLIO CASE STUDY
-- Source: RAND Health Insurance Experiment; statsmodels subset (20,190 records)
-- Run on: SQLite, using data/visits.sqlite built by analysis/run_analysis.py
-- All rows are records in the public study subset, NOT unique people.

DROP VIEW IF EXISTS v_overview;
CREATE VIEW v_overview AS
SELECT COUNT(*) AS records,
       SUM(outpatient_visits) AS total_visits,
       ROUND(AVG(outpatient_visits), 3) AS avg_visits_per_record,
       ROUND(100.0 * SUM(CASE WHEN outpatient_visits = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS zero_visit_pct,
       ROUND(100.0 * SUM(CASE WHEN outpatient_visits >= 8 THEN 1 ELSE 0 END) / COUNT(*), 2) AS high_utilization_pct
FROM visits;

DROP VIEW IF EXISTS v_health;
CREATE VIEW v_health AS
SELECT health_status,
       COUNT(*) AS records,
       SUM(outpatient_visits) AS visits,
       ROUND(AVG(outpatient_visits), 3) AS avg_visits,
       SUM(CASE WHEN outpatient_visits = 0 THEN 1 ELSE 0 END) AS zero_visit_records,
       ROUND(100.0 * SUM(CASE WHEN outpatient_visits = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS zero_visit_pct
FROM visits GROUP BY health_status;

DROP VIEW IF EXISTS v_cost_share;
CREATE VIEW v_cost_share AS
SELECT coinsurance_pct,
       COUNT(*) AS records,
       SUM(outpatient_visits) AS visits,
       ROUND(AVG(outpatient_visits), 3) AS avg_visits,
       SUM(CASE WHEN outpatient_visits = 0 THEN 1 ELSE 0 END) AS zero_visit_records,
       ROUND(100.0 * SUM(CASE WHEN outpatient_visits = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS zero_visit_pct
FROM visits GROUP BY coinsurance_pct;

DROP VIEW IF EXISTS v_cross_segment;
CREATE VIEW v_cross_segment AS
SELECT health_status, coinsurance_pct, COUNT(*) AS records,
       SUM(outpatient_visits) AS visits,
       ROUND(AVG(outpatient_visits), 3) AS avg_visits,
       ROUND(100.0 * SUM(CASE WHEN outpatient_visits=0 THEN 1 ELSE 0 END)/COUNT(*), 2) AS zero_visit_pct
FROM visits GROUP BY health_status, coinsurance_pct;

DROP VIEW IF EXISTS v_qa;
CREATE VIEW v_qa AS
SELECT COUNT(*) AS records,
       COUNT(DISTINCT record_id) AS unique_record_ids,
       SUM(CASE WHEN outpatient_visits < 0 THEN 1 ELSE 0 END) AS invalid_visit_counts,
       SUM(CASE WHEN coinsurance_pct NOT IN (0,25,50,95,100) THEN 1 ELSE 0 END) AS invalid_cost_share,
       SUM(CASE WHEN health_status NOT IN ('Excellent','Good','Fair','Poor') THEN 1 ELSE 0 END) AS invalid_health_status,
       SUM(CASE WHEN outpatient_visits IS NULL OR health_status IS NULL OR coinsurance_pct IS NULL THEN 1 ELSE 0 END) AS critical_nulls
FROM visits;

-- Sample stakeholder-ready questions:
-- SELECT * FROM v_overview;
-- SELECT * FROM v_health ORDER BY avg_visits DESC;
-- SELECT * FROM v_cost_share ORDER BY coinsurance_pct;
-- SELECT * FROM v_cross_segment WHERE records >= 100 ORDER BY avg_visits DESC;
-- SELECT * FROM v_qa;
