# BI handoff | Power BI or Tableau

This is an **implementation guide**, not a fabricated Power BI `.pbix` or Tableau `.twb` file. The included web and Excel dashboards are complete; Olu can rebuild them in his actual BI software to produce an additional genuine work sample.

## Data source

Import `data/visits_clean.csv` into Power BI or Tableau. Set `record_id` and `outpatient_visits` to whole numbers, `health_status` and `visit_band` to text, and `coinsurance_pct` to a whole-number percentage value (0, 25, 50, 95, 100). **Do not format the number 25 as an Excel percent directly** or it will display as 2,500%; instead use a text label `coinsurance_pct & "%"` or divide by 100 in a separate calculated field.

## Power BI DAX measures

```dax
Study Records = COUNTROWS(visits_clean)

Total MD Visits = SUM(visits_clean[outpatient_visits])

Mean Visits Per Record = DIVIDE([Total MD Visits], [Study Records])

Zero-Visit Records =
  CALCULATE(COUNTROWS(visits_clean), visits_clean[outpatient_visits] = 0)

Zero-Visit Share = DIVIDE([Zero-Visit Records], [Study Records])

High-Utilization Records =
  CALCULATE(COUNTROWS(visits_clean), visits_clean[outpatient_visits] >= 8)
```

Suggested visual layout:

- KPI cards: Study Records, Total MD Visits, Mean Visits, Zero-Visit Share.
- Bar chart: mean visits by health status (sort Excellent / Good / Fair / Poor).
- Bar chart: zero-visit share by coinsurance group.
- Donut or column: distribution of `visit_band` (0 / 1-2 / 3-5 / 6-10 / 11+).
- Slicers: health status and coinsurance percentage.
- Annotation: "Historical RAND HIE; records are not unique people; descriptive only."

## Tableau equivalents

Create calculated fields `IF [outpatient_visits] = 0 THEN 1 ELSE 0 END` for zero-visit indicator; `AVG([outpatient_visits])` for mean utilization; `AVG([zero_visit_indicator])` for zero-visit share. Build the same three visuals, and apply data-source filters consistently.

## Data quality guardrails

**Validate against the original script:** unfiltered `COUNT=20,190`, `SUM(outpatient_visits)=57,752`, `AVG(outpatient_visits)≈2.8604`, and zero-visit share `≈31.243%`. Remember: these are 20,190 records, not unique patients.
