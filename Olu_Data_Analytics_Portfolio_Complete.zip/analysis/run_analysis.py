"""Reproduce the public-data portfolio analysis with pandas, NumPy, and SQLite.

Run from the portfolio project root:
    python analysis/run_analysis.py
Dependencies: pandas, numpy, statsmodels.

Source: statsmodels RAND Health Insurance Experiment subset (public domain).
https://www.statsmodels.org/stable/datasets/generated/randhie.html
These are historical study records, not current healthcare utilization or unique people.
"""
from pathlib import Path
import csv
import json
import sqlite3
import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)

raw = sm.datasets.randhie.load_pandas().data.copy()
assert len(raw) == 20190
assert len(raw.columns) == 10
assert raw.isna().sum().sum() == 0
raw.to_csv(DATA / 'randhie_raw.csv', index=False)

# The supplied indicator fields are mutually exclusive; missing indicators
# represent "Excellent", the original data's omitted reference category.
health_flags = raw[['hlthg', 'hlthf', 'hlthp']]
assert health_flags.isin([0, 1]).all().all()
assert (health_flags.sum(axis=1) <= 1).all()
health = np.select(
    [raw['hlthp'].eq(1), raw['hlthf'].eq(1), raw['hlthg'].eq(1)],
    ['Poor', 'Fair', 'Good'], default='Excellent'
)
# Official definition: lncoins = ln(coinsurance + 1)
# expm1 restores rate (%) accurately before rounding displayed bands.
coins = np.rint(np.expm1(raw['lncoins'])).astype(int)
assert set(coins.unique()) == {0, 25, 50, 95, 100}

visits = raw['mdvis'].astype(int)
assert (visits >= 0).all()
clean = pd.DataFrame({
    'record_id': np.arange(1, len(raw) + 1),
    'outpatient_visits': visits,
    'health_status': health,
    'coinsurance_pct': coins,
    'individual_deductible_plan': raw['idp'].astype(int),
    'has_visit': visits.gt(0).astype(int),
    'high_utilization_8plus': visits.ge(8).astype(int),
    'visit_band': pd.cut(visits, bins=[-1,0,2,5,10,1000], labels=['0','1-2','3-5','6-10','11+']).astype(str)
})
assert clean['record_id'].is_unique
assert clean.notna().sum().sum() == clean.size
clean.to_csv(DATA / 'visits_clean.csv', index=False)

records = len(clean)
total_visits = int(clean.outpatient_visits.sum())
zero = int(clean.outpatient_visits.eq(0).sum())
high_visits = int(clean.high_utilization_8plus.sum())

health_order = ['Excellent', 'Good', 'Fair', 'Poor']
cost_order = [0,25,50,95,100]
bands = ['0','1-2','3-5','6-10','11+']

def summarize(df, keys):
    out = (df.groupby(keys, observed=True).agg(
         records=('record_id','size'),
         total_visits=('outpatient_visits','sum'),
         zero_visit_records=('outpatient_visits',lambda x: int((x == 0).sum())),
         high_utilization_records=('high_utilization_8plus','sum')
    ).reset_index())
    out['avg_visits'] = (out.total_visits/out.records).round(4)
    out['zero_visit_pct'] = (100*out.zero_visit_records/out.records).round(4)
    return out

hs = summarize(clean,['health_status'])
cs = summarize(clean,['coinsurance_pct'])
xg = summarize(clean,['health_status','coinsurance_pct'])
hs['health_status'] = pd.Categorical(hs.health_status, health_order, ordered=True)
hs.sort_values('health_status').to_csv(DATA / 'summary_health.csv', index=False)
cs.sort_values('coinsurance_pct').to_csv(DATA / 'summary_coinsurance.csv', index=False)
xg['health_status'] = pd.Categorical(xg.health_status, health_order, ordered=True)
xg.sort_values(['health_status','coinsurance_pct']).to_csv(DATA / 'summary_cross_segments.csv', index=False)

with sqlite3.connect(DATA/'visits.sqlite') as connection:
    clean.to_sql('visits',connection,if_exists='replace',index=False)
    connection.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_visits_id ON visits(record_id)')
    connection.execute('CREATE INDEX IF NOT EXISTS idx_visits_segment ON visits(health_status, coinsurance_pct)')
    connection.executescript((ROOT/'analysis'/'sql_queries.sql').read_text())
    qa = pd.read_sql_query('SELECT * FROM v_qa',connection).iloc[0].to_dict()
    ov = pd.read_sql_query('SELECT * FROM v_overview',connection).iloc[0].to_dict()
    assert int(qa['records']) == int(qa['unique_record_ids']) == records
    assert all(int(qa[k])==0 for k in ['invalid_visit_counts','invalid_cost_share','invalid_health_status','critical_nulls'])
    assert int(ov['total_visits']) == total_visits
    pd.read_sql_query('SELECT * FROM v_health ORDER BY CASE health_status WHEN "Excellent" THEN 1 WHEN "Good" THEN 2 WHEN "Fair" THEN 3 ELSE 4 END',connection).to_csv(DATA/'sql_verified_summary.csv',index=False)

# Small JSON snapshot for portable HTML (no runtime dependencies or private data)
grouped=[]
for (health_status, cost), df in clean.groupby(['health_status','coinsurance_pct']):
    by_band = df.visit_band.value_counts().reindex(bands,fill_value=0)
    grouped.append({
       'health':str(health_status), 'coin':int(cost), 'n':len(df),
       'visits':int(df.outpatient_visits.sum()),
       'zero':int(df.outpatient_visits.eq(0).sum()),
       'high':int(df.high_utilization_8plus.sum()),
       'high_visits':int(df.loc[df.high_utilization_8plus.eq(1),'outpatient_visits'].sum()),
       'bands':by_band.to_dict()
    })
metric = {
 'records':records, 'total_visits':total_visits,
 'avg_visits':round(total_visits/records,4),
 'zero_visit_pct':round(100*zero/records,4),
 'high_utilization_pct':round(100*high_visits/records,4),
 'high_utilization_share_visits_pct':round(100*clean.loc[clean.high_utilization_8plus.eq(1),'outpatient_visits'].sum()/total_visits,4),
 'grouped':sorted(grouped,key=lambda d:(health_order.index(d['health']),d['coin'])),
 'source':'https://www.statsmodels.org/stable/datasets/generated/randhie.html'
}
(ROOT/'dashboard'/'snapshot.json').write_text(json.dumps(metric,indent=2))

# Minimal data dictionary covering columns used in the dashboard.
rows = [
('record_id','Synthetic row identifier for this exported subset, not patient ID','1 .. 20,190'),
('outpatient_visits','Physician outpatient visits recorded for the study row','0 or greater'),
('health_status','Self-rated health, reconstructed from three binary flags','Excellent / Good / Fair / Poor'),
('coinsurance_pct','Rounded exp(lncoins) - 1, where lncoins is natural-log coded rate','0 / 25 / 50 / 95 / 100'),
('individual_deductible_plan','Whether the record belonged to an individual deductible plan','0 / 1'),
('has_visit','Whether outpatient_visits > 0','0 / 1'),
('high_utilization_8plus','Whether outpatient_visits >= 8','0 / 1'),
('visit_band','Descriptive outpatient visit interval','0 / 1-2 / 3-5 / 6-10 / 11+'),
]
with (DATA/'data_dictionary.csv').open('w',newline='') as f:
    writer=csv.writer(f)
    writer.writerow(['field','definition','values'])
    writer.writerows(rows)
print(f'Reproduced {records:,} historical records; {total_visits:,} outpatient visits; {100*zero/records:.2f}% with zero visits.')
print(f'Checks: 0 missing values; 0 critical domain errors; SQL totals match pandas.')
