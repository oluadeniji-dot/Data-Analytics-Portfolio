# Olu | Data & Operations Analytics

**Portfolio case study: Healthcare Service Utilization**  
**Focus:** data validation, SQL reporting, Python analytics, spreadsheet dashboards, and clear stakeholder communication.

[Open the interactive dashboard](index.html) · [Read the 2-page PDF](docs/Case_Study.pdf) · [Open the Excel dashboard](docs/Analytics_Summary.xlsx)

## The question

How are outpatient physician visits distributed across historical records, and how do visits differ by self-rated health and insurance cost-sharing groups?

This is a **public-data work sample**. It is *not* a previous employer/client project, a current healthcare report, or a claim to have personally collected the data. The project was initially prepared with AI assistance; Olu should **review, run, adapt, and be able to explain the code and conclusions** before presenting it as his own demonstrated portfolio work.

## The dataset

- **Source:** RAND Health Insurance Experiment dataset subset, distributed by `statsmodels`.
- **Reference:** <https://www.statsmodels.org/stable/datasets/generated/randhie.html>
- **Original study:** <https://doi.org/10.3886/ICPSR06439.v1>
- **Historical collection:** 1974–1982; included subset is historical and should not be presented as current demand.
- **Size:** 20,190 study records and 10 original fields.
- **Copyright:** statsmodels documents this subset as **public domain**. Source credit is provided throughout this portfolio.
- **Unit of analysis:** an observed record in the packaged dataset, **not a unique patient or person**. The derived `record_id` is a local row number, not a person identifier.

The records include outpatient MD visits, an encoded coinsurance rate, and self-rated health indicators. The raw source subset is retained in `data/randhie_raw.csv`.

## Key findings (all 20,190 records)

| Measure | Verified result |
|---|---:|
| Total recorded outpatient physician visits | 57,752 |
| Average visits per record | 2.86 |
| Records with zero visits | 6,308 (31.24%) |
| Records with 8+ visits | 1,851 (9.17%) |
| Portion of total visits from records with 8+ visits | 42.6% |
| Avg visits: excellent self-rated health (11,019 records) | 2.63 |
| Avg visits: poor self-rated health (302 records) | 5.79 |

The variation illustrates why good operational reporting should show **segment sizes, averages, and distributions**, not just one summary number. These are **descriptive**, historical differences: don't interpret them as causal effects, population-level healthcare forecasts, or clinical advice.

## Reproduce from scratch

Python 3.10+ with these widely used packages is sufficient:

```bash
pip install pandas numpy statsmodels
python analysis/run_analysis.py
```

The Python script reloads the subset distributed with `statsmodels`, writes the raw and cleaned CSV files, creates `data/visits.sqlite`, installs the SQL views in `analysis/sql_queries.sql`, checks SQL results against pandas, and exports `dashboard/snapshot.json` with anonymous aggregated counts for the static interactive dashboard.

The prepared data uses these documented rules:

1. Self-rated health is `Poor`, `Fair`, or `Good` if its respective binary flag is 1; otherwise `Excellent` (the omitted category). The source flags are checked for exclusivity.
2. Coinsurance group (%) is `round(exp(lncoins) - 1)`, because the original field is a natural log of `coinsurance + 1`.
3. The visit count is `mdvis`; the 8+ grouping is a descriptive reporting threshold, not a medical standard.
4. Python and SQLite use identical record-level denominators, which avoids silently mixing persons and observations.

### Quality checks

- All 20,190 rows load with **no missing values**.
- No duplicate *local* `record_id` values, negative visit counts, or unexpected coinsurance groups.
- All health indicators are mutually exclusive in the source.
- SQL total visits exactly match Python's **57,752**.

## Files

| Path | Purpose |
|---|---|
| `index.html` | Responsive, fully self-contained dashboard with health/cost-share filters (no external JS/CSS dependencies) |
| `docs/Case_Study.pdf` | Polished, two-page case study for a fast recruiter review |
| `docs/Analytics_Summary.xlsx` | Formula-driven Excel summary with charts, segment tables, and 150 representative sample records |
| `analysis/run_analysis.py` | Reproducible transform, quality checks, segment summaries and SQL cross-validation |
| `analysis/sql_queries.sql` | SQL views for KPI, health, coinsurance, cross-segment and QA reporting |
| `analysis/BI_Handoff.md` | Power BI / Tableau implementation notes; not a claim that a native `.pbix` or `.twb` was produced |
| `data/randhie_raw.csv` | Public-domain source subset |
| `data/visits_clean.csv` | Prepared dataset: one row per study record |
| `data/visits.sqlite` | Queryable SQLite database containing the validated views |
| `data/data_dictionary.csv` | Data definitions, transformation assumptions |
| `data/summary_*.csv` | Exported aggregate summaries |
| `dashboard/snapshot.json` | Aggregated anonymous counts backing the interactive dashboard |

## Notes about the spreadsheet

The Excel workbook includes calculated averages, calculated zero-visit rates, source credits and charts. For a convenient recruiter download, its `Sample_Records` tab contains **150 sample rows**. The full 20,190-row prepared dataset is provided separately in the CSV and SQLite files.

## How to publish for Handshake AI

**Fastest option:** Upload `docs/Case_Study.pdf` to Olu's Google Drive, choose Share → General access → **Anyone with the link** → Viewer, copy that public *PDF sharing link*, and paste it into the Handshake portfolio field. Confirm the link opens in a private/incognito browser window.

**Best option (GitHub portfolio):** Create a **public** GitHub repository (for example `data-analytics-portfolio`), upload this directory with its structure preserved, and enable **Settings → Pages → Deploy from a branch → `main` → `/ (root)`**. GitHub will provide a public site URL for `index.html`. Paste that **actual GitHub Pages URL** in Handshake after checking it loads. The repository URL is also acceptable and includes code evidence.

**Before submitting:** Ask Olu to inspect the files, run the script, check that every claimed tool and year in his survey is truthful, and be comfortable explaining the transformation and findings. Do not present this public sample as work performed for his former employer.

## What this demonstrates vs. Olu's professional work

This sample demonstrates a **transferable workflow** (quality control → clean measures → SQL verification → dashboard → recommendations). Olu's real SQL query tuning, Power BI reporting and operational analytics experience should be described **separately and only using results he can confirm**. The project does *not* claim that the public dataset contains his employer's device, employee, or customer records.

## Attribution

RAND Health Insurance Experiment data distributed in the public-domain `statsmodels` dataset collection, used and transformed here solely as a public portfolio demonstration. Source: <https://www.statsmodels.org/stable/datasets/generated/randhie.html>. Original study: <https://doi.org/10.3886/ICPSR06439.v1>.
